<?php
require("template.php");

# Now set the title of the page:
setPageTitle("A Look At Progress");

# Make the header.
generateHeader($_SERVER['PHP_SELF']);
?>

<div class="textheader">Future Goals</div>
<p>This still needs filling in, but be assured it will contain something like, "become an even better library."</p>

<?php generateFooter(); ?>
