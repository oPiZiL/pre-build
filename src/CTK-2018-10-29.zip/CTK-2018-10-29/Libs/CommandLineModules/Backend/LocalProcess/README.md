Local Process    {#CommandLineModulesBackendLocalProcess_Page}
=============

\internal This page is best viewed in its [Doxygen processed]
(http://www.commontk.org/docs/html/CommandLineModulesBackendLocalProcess_Page.html) form. \endinternal

The Local Process back-end is a fully featured back-end implementation for handling executable
modules. When registered with a ctkCmdLineModuleManager instance, it will handle the registration
of all modules with a "file" location URL scheme. See the ctkCmdLineModuleBackendLocalProcess class
for details.

See the \ref CommandLineModulesBackendLocalProcess_API module for the API documentation.
