Core    {#CommandLineModulesCore_Page}
====

\internal This page is best viewed in its [Doxygen processed]
(http://www.commontk.org/docs/html/CommandLineModulesCore_Page.html) form. \endinternal

The Command Line Modules Core library provides high-level classes to manage command line modules.

It provides abstract classes for working with back and front ends and a central management class
for registering and running modules, the ctkCmdLineModuleManager.

See the \ref CommandLineModulesCore_API module for the API documentation.
